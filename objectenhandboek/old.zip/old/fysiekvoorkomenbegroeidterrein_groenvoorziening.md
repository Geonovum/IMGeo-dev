<div>

### BegroeidTerreindeel, fysiekVoorkomen: groenvoorziening

![dsc\_2326](media/image54.jpg)

C en D (afzonderlijke objecten):

  ***BegroeidTerreindeel***   ***Attribuutwaarde***   ***Opmerkingen***
  --------------------------- ----------------------- -------------------
  fysiekVoorkomen             Groenvoorziening        
  relatieveHoogteligging       0                       

A en B: wegdeel, voetpad, open verharding.

![dsc\_2321](media/image55.jpg)

B:

  ***BegroeidTerreindeel***   ***Attribuutwaarde***   ***Opmerkingen***
  --------------------------- ----------------------- ---------------------------------
  fysiekVoorkomen             Groenvoorziening        Plantvak opnemen want \> 5 m^2^
  relatieveHoogteligging       0                       

A: wegdeel, rijbaan: lokale weg, openverharding.

Objecttype: Waterdeel
---------------------

</div>
