<div>

### OverigBouwwerk, type: bezinkbak

![](media/image67.jpg)

A:

  ------------------------ --------------------- -----------------
  **OverigBouwwerk**       **Attribuutwaarde**   **Opmerkingen**
  type                     bezinkbak              
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

B: onbegroeidterreindeel, onverhard.

</div>
