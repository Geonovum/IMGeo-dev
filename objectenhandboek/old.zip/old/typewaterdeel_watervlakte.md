<div>

### Waterdeel, type: watervlakte

![](media/image59.jpg)

A:

  ------------------------ --------------------- -----------------
  **Waterdeel**            **Attribuutwaarde**   **Opmerkingen**
  type                     watervlakte            
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

B: OndersteunendWaterdeel, Oever/slootkant

</div>
