<div>

### BegroeidTerreindeel, fysiekVoorkomen: kwelder

![](media/image48.jpg)

A:

  --------------------------- --------------------- -----------------
  **OnbegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen             kwelder                
  relatieveHoogteligging       0                     
  --------------------------- --------------------- -----------------

B: waterloop.

</div>
