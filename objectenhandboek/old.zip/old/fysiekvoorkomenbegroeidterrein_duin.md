<div>

### BegroeidTerreindeel, fysiekVoorkomen: duin

![](media/image44.jpg)

B:

  ------------------------- --------------------- -----------------
  **BegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen           duin                   
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

</div>
