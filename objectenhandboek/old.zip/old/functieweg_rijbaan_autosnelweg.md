<div>

### Wegdeel, functie: rijbaan: autosnelweg

![](media/image5.jpg)

A en B:

  ------------------------ ---------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**    **Opmerkingen**
  Functie                  rijbaan: autosnelweg    
  fysiekVoorkomen           Gesloten verharding    
  relatieveHoogteligging    0                      
  ------------------------ ---------------------- -----------------

C: Ondersteunend wegdeel: Berm, fysiek voorkomen: Groenvoorziening.

D (meerdere objecten): IMGeo: Type weginrichting, Geleideconstructie.

</div>
