<div>

### OverigBouwwerk, type: open loods

![](media/image65.jpg)

A:

  ------------------------ --------------------- -----------------
  **OverigBouwwerk**       **Attribuutwaarde**   **Opmerkingen**
  type                     open loods             
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

Ten behoeve van de vlakvormige objectvorming is de open zijde van de
loods gesloten.

</div>
