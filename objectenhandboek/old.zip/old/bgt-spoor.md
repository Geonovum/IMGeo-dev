**Objecttype Spoor**
--------------------

### Spoor, type: trein

![](media/64546c37fabdf1decd2299edd4002ea7.jpg)

C (verschillende objecten):

| **Spoor**              | **Attribuutwaarde** | **Opmerkingen** |
|------------------------|---------------------|-----------------|
| functie                | trein               |                 |
| relatieveHoogteligging |  0                  |                 |

A: Wegdeel, Overweg.

B: Wegdeel, functie: Spoorbaan.

### Spoor, type: sneltram

![sneltram.jpg](media/c5a3e34f01048b4ece76308d2e457f10.jpg)

A en B (gescheiden objecten):

| **Spoor**              | **Attribuutwaarde** | **Opmerkingen** |
|------------------------|---------------------|-----------------|
| functie                | sneltram            |                 |
| relatieveHoogteligging |  0                  |                 |

Een (spoorbaan voor de) metro beschouwt de BGT als een verbijzondering van een
(spoorbaan voor) sneltram.

### Spoor, type: tram

![tram.jpg](media/5357654e07df263db26359a2a4a730e2.jpg)

A en B (gescheiden objecten):

| **Spoor**              | **Attribuutwaarde** | **Opmerkingen** |
|------------------------|---------------------|-----------------|
| functie                | Tram                |                 |
| relatieveHoogteligging |  0                  |                 |
