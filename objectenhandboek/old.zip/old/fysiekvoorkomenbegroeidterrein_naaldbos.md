<div>

### BegroeidTerreindeel, fysiekVoorkomen: naaldbos

![](media/image40.jpg)

  ------------------------- --------------------- -----------------
  **BegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen           naaldbos               
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

</div>
