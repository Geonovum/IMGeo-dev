<div>

### Spoor, type: sneltram

![sneltram.jpg](media/image31.jpg)

A en B (gescheiden objecten):

  ------------------------ --------------------- -----------------
  **Spoor**                **Attribuutwaarde**   **Opmerkingen**
  functie                  sneltram               
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

Een (spoorbaan voor de) metro beschouwt de BGT als een verbijzondering
van een (spoorbaan voor) sneltram.

</div>
