<div>

### OnbegroeidTerreindeel, fysiekVoorkomen: onverhard

![](media/image35.jpg)

A:

  --------------------------- --------------------- -----------------
  **OnbegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen             onverhard              
  relatieveHoogteligging       0                     
  --------------------------- --------------------- -----------------

B: waterdeel, waterloop.

C: ondersteunend waterdeel, oever/slootkant.

</div>
