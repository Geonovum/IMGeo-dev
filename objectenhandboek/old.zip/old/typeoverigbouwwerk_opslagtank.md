<div>

### OverigBouwwerk, type: opslagtank

![](media/image66.jpg)

C en E:

  ------------------------ --------------------- -----------------
  **OverigBouwwerk**       **Attribuutwaarde**   **Opmerkingen**
  type                     Opslagtank             
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

A: wegdeel, rijbaan: lokale weg.

B en D: onbegroeidterreindeel, erf.

</div>
