<div>

### Wegdeel, functie: rijbaan: autoweg

![](media/image6.jpg)

A:

  ------------------------ ---------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**    **Opmerkingen**
  functie                  rijbaan: autoweg        
  fysiekVoorkomen           Gesloten verharding    
  relatieveHoogteligging    0                      
  ------------------------ ---------------------- -----------------

</div>
