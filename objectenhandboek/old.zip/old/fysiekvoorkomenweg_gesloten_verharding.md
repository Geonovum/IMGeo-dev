<div>

### Wegdeel, fysiekVoorkomen: gesloten verharding

![dsc\_2340](media/image23.jpg)

B en D (afzonderlijke objecten):

  ***Wegdeel***            ***Attribuutwaarde***   ***Opmerkingen***
  ------------------------ ----------------------- -------------------
  functieWeg               Rijbaan: lokale weg     
  fysiek voorkomen         Gesloten verharding     
  relatieveHoogteligging   0                       

A: Wegdeel, Voetpad, Open verharding.

C: op volgende bladzijde.

E: Begroeid terreindeel, Groenvoorziening.

</div>
