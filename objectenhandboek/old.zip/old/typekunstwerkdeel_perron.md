<div>

### Kunstwerkdeel, type: perron

![](media/image83.jpg)

C:

  ------------------------- --------------------- -----------------
  **overigKunstwerkdeel**   **Attribuutwaarde**   **Opmerkingen**
  type                      perron                 
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

A: wegdeel, spoorbaan.

B: spoor, trein.

![DSCN2122](media/image84.jpg)

Dit is geen perron.

Perrons worden alleen opgenomen als ze langs een spoor van trein of
sneltram liggen.

A is voor de BGT een wegdeel, in IMGeo kan het tevens worden
geclassificeerd als: Functioneel gebied, niet BGT, bushalte.

A:

  ***Wegdeel***            ***Attribuutwaarde***   ***Opmerkingen***
  ------------------------ ----------------------- -------------------
  functieWeg               Voetpad                 
  fysiek voorkomen         Open verharding         
  relatieveHoogteligging   0                       

</div>
