<div>

### Spoor, type: tram

![tram.jpg](media/image32.jpg)

A en B (gescheiden objecten):

  ------------------------ --------------------- -----------------
  **Spoor**                **Attribuutwaarde**   **Opmerkingen**
  functie                  Tram                   
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

Objecttype: OnbegroeidTerreindeel
---------------------------------

</div>
