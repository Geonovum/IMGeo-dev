<div>

### BegroeidTerreindeel, fysiekVoorkomen: fruitteelt

![](media/image49.jpg)

A:

  ------------------------- --------------------- -----------------
  **BegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen           fruitteelt             
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

**\
**

</div>
