<div>

### OnbegroeidTerreindeel, fysiekVoorkomen: half verhard

Foto zie 2.1.19, wegdeel, half verhard.

  --------------------------- --------------------- -----------------
  **OnbegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen             half verhard           
  relatieveHoogteligging       0                     
  --------------------------- --------------------- -----------------

</div>
