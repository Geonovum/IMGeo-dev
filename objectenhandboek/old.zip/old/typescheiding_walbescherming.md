<div>

### Scheiding, type: walbescherming

![](media/image95.jpg)

D en E:

  ------------------------ --------------------- -----------------
  **Scheiding**            **Attribuutwaarde**   **Opmerkingen**
  type                     walbescherming         
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

A: waterdeel, waterloop.

B en C: begroeid terreindeel, groenvoorziening.

</div>
