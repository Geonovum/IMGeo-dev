<div>

### Wegdeel, functie: overweg

![](media/image3.jpg)

A:

  ------------------------ ---------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**    **Opmerkingen**
  functie                  overweg                 
  fysiekVoorkomen           Gesloten verharding    
  relatieveHoogteligging    0                      
  ------------------------ ---------------------- -----------------

B: Wegdeel, Spoorbaan.

C: Spoor, Trein.

</div>
