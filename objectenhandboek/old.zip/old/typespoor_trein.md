<div>

### Spoor, type: trein

![](media/image3.jpg)

C (verschillende objecten):

  ------------------------ --------------------- -----------------
  **Spoor**                **Attribuutwaarde**   **Opmerkingen**
  functie                  trein                  
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

A: Wegdeel, Overweg.

B: Wegdeel, functie: Spoorbaan.

</div>
