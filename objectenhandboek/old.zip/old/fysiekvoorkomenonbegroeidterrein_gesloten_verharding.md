<div>

### OnbegroeidTerreindeel, fysiekVoorkomen: gesloten verharding

Foto zie 2.1.17, wegdeel, gesloten verharding.

A:

  --------------------------- --------------------- -----------------
  **OnbegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen             gesloten verharding    
  relatieveHoogteligging       0                     
  --------------------------- --------------------- -----------------

</div>
