<div>

### BegroeidTerreindeel, fysiekVoorkomen: loofbos

![](media/image37.jpg)

![P1060140](media/image38.jpg)

A:

  ------------------------- --------------------- -----------------
  **BegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen           loofbos                
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

</div>
