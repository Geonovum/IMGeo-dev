<div>

### BegroeidTerreindeel, fysiekVoorkomen: heide

![heide.JPG](media/image41.jpg)

  ------------------------- --------------------- -----------------
  **BegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen           heide                  
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

</div>
