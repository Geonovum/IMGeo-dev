<div>

### BegroeidTerreindeel, fysiekVoorkomen: gemengd bos

![](media/image39.jpg)

  ------------------------- --------------------- -----------------
  **BegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen           gemengd bos            
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

</div>
