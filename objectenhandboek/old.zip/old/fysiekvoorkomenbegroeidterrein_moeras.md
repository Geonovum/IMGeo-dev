<div>

### BegroeidTerreindeel, fysiekVoorkomen: moeras

![](media/image46.jpg)

A:

  ------------------------- --------------------- -----------------
  **BegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen           moeras                 
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

</div>
