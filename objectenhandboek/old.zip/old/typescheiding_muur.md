<div>

### Scheiding, type: muur

![](media/image90.jpg)

D:

  ------------------------ --------------------- ----------------------------------------------------------------------------------
  **Scheiding**            **Attribuutwaarde**   **Opmerkingen**
  type                     muur                  Muur met hek is \> 1m hoog; de voet van de muur aan de straatzijde is BGT-inhoud
  relatieveHoogteligging    0                    
  ------------------------ --------------------- ----------------------------------------------------------------------------------

A: wegdeel, rijbaan: lokale weg, open verharding.

B: pand

C: onbegroeid terreindeel, erf.

![2325b](media/image14.jpg)

C en D zijn BGT-inhoud want de hoogte van de muur \> 0,5 m. Het zijn
afzonderlijke objecten omdat de onderbreking bij A \> 1 m.

C en D:

  ***Scheiding***          ***Attribuutwaarde***   ***Opmerkingen***
  ------------------------ ----------------------- -----------------------------
  typeScheiding            Muur                    Lijn, want breedte \< 0.3 m
  relatieveHoogteligging    0                      

A: onbegroeid terreindeel, open verharding.

B: wegdeel, voetpad, open verharding.

</div>
