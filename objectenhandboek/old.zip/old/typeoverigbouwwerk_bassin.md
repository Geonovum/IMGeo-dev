<div>

### OverigBouwwerk, type: bassin

![](media/image70.jpg)

![](media/image71.jpg)

2xA:

  ------------------------ --------------------- -----------------
  **OverigBouwwerk**       **Attribuutwaarde**   **Opmerkingen**
  type                     bassin                 
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

Objecttype: Overbruggingsdeel
-----------------------------

</div>
