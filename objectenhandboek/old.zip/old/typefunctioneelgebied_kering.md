<div>

### Functioneel gebied, type: kering

Een kaartje wordt nog toegevoegd waarop dit functioneel gebied is
afgebeeld op de topografie.

  ------------------------ --------------------- -----------------
  **Functioneel gebied**   **Attribuutwaarde**   **Opmerkingen**
  type                     kering                 
  ------------------------ --------------------- -----------------

</div>
