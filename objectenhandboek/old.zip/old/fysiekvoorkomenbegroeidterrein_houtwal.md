<div>

### BegroeidTerreindeel, fysiekVoorkomen: houtwal

![P1060155](media/image43.jpg)

B:

  ***BegroeidTerreindeel***   ***Attribuutwaarde***   ***Opmerkingen***
  --------------------------- ----------------------- -------------------
  fysiekVoorkomen             houtwal                 
  relatieveHoogteligging      0                        

A: waterdeel, greppel/droge sloot.

</div>
