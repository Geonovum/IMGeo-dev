<div>

### OverigBouwwerk, type: windturbine

![windturbine.jpg](media/image68.jpg)

Uitsluitend de maaiveldgeometrie van de windmolenmast vormt BGT-inhoud.

  ------------------------ --------------------- -----------------
  **OverigBouwwerk**       **Attribuutwaarde**   **Opmerkingen**
  type                     windturbine            
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

</div>
