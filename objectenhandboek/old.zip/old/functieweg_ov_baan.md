<div>

### Wegdeel, functie: OV-baan

![](media/image1.jpg)

A:

  ------------------------ --------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**   **Opmerkingen**
  functie                  OV-baan                
  fysiekVoorkomen          Gesloten verharding    
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

B en C: ondersteunend wegdeel: verkeerseiland, fysiek voorkomen: open
verharding, niveau 0.

D: wegdeel, voetpad, open verharding, niveau 0.

Omdat de afscheiding met de OV-baan bestaat uit belijning, zijn de
fietsstroken daarop geen BGT-inhoud.

![](media/image2.jpg)

A:

  ------------------------ ---------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**    **Opmerkingen**
  functie                  OV-baan                 
  fysiekVoorkomen           Gesloten verharding    
  relatieveHoogteligging    0                      
  ------------------------ ---------------------- -----------------

B en C: Begroeid terreindeel, Groenvoorziening.

D, E en F: Ondersteunend wegdeel: Verkeerseiland, fysiek voorkomen: open
verharding.

</div>
