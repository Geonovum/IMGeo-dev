<div>

### Wegdeel, functie: spoorbaan

![](media/image3.jpg)

B:

  ------------------------ --------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**   **Opmerkingen**
  functie                  spoorbaan              
  fysiekVoorkomen           Half verhard          
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

A: Wegdeel, Overweg.

C: Spoor, Trein.

</div>
