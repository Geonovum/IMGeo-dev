<div>

### Wegdeel, functie: rijbaan: regionale weg

![](media/image7.jpg)

A:

  ------------------------ ------------------------ -----------------
  **Wegdeel**              **Attribuutwaarde**      **Opmerkingen**
  functie                  rijbaan: regionale weg    
  fysiekVoorkomen           Gesloten verharding      
  relatieveHoogteligging    0                        
  ------------------------ ------------------------ -----------------

</div>
