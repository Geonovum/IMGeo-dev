<div>

### Wegdeel, functie: baan voor vliegverkeer

![](media/image4.jpg)

A:

  ------------------------ ------------------------ -----------------
  **Wegdeel**              **Attribuutwaarde**      **Opmerkingen**
  functie                  baan voor vliegverkeer    
  fysiekVoorkomen           Gesloten verharding      
  relatieveHoogteligging    0                        
  ------------------------ ------------------------ -----------------

B, C en D: Begroeid terreindeel, Grasland overig.

</div>
