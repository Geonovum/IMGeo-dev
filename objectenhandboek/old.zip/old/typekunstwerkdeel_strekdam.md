<div>

### Kunstwerkdeel, type: strekdam

![](media/image86.jpg)

A:

  ------------------------- --------------------- -----------------
  **overigKunstwerkdeel**   **Attribuutwaarde**   **Opmerkingen**
  type                      strekdam               
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

</div>
