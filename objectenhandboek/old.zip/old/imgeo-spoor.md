#### Spoor, niet BGT, plus: havenkraan

Een afbeelding van een spoor havenkraan kunt u sturen aan:
[imgeo\@geonovum.nl](mailto:info@geonovum.nl)

| **Spoor**              | **Attribuutwaarde** | **Opmerkingen** |
|------------------------|---------------------|-----------------|
| functie                | Havenkraan          |                 |
| relatieveHoogteligging |  0                  |                 |
