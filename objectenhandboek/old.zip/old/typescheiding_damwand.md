<div>

### Scheiding, type: damwand

![kademuur3.jpg](media/image93.jpg)

A:

  ------------------------ --------------------- -----------------
  **Scheiding**            **Attribuutwaarde**   **Opmerkingen**
  type                     damwand                
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

</div>
