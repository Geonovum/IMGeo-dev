<div>

### BegroeidTerreindeel, fysiekVoorkomen: bouwland

![](media/image51.jpg)

![](media/image52.jpg)

A:

  ------------------------- --------------------- -----------------
  **BegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen           bouwland               
  relatieveHoogteligging     0                     
  ------------------------- --------------------- -----------------

</div>
