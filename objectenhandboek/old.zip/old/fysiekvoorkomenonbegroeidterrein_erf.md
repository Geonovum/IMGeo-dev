<div>

### OnbegroeidTerreindeel, Fysiek voorkomen: erf

![](media/image33.jpg)

A:

  --------------------------- --------------------- -----------------
  **OnbegroeidTerreindeel**   **Attribuutwaarde**   **Opmerkingen**
  fysiekVoorkomen             erf                    
  relatieveHoogteligging       0                     
  --------------------------- --------------------- -----------------

</div>
