<div>

### Waterdeel, type: greppel/droge sloot

![P1060135](media/image60.jpg)

B:

  ***Waterdeel***          ***Attribuutwaarde***   ***Opmerkingen***
  ------------------------ ----------------------- -------------------
  type water               Greppel/droge sloot     
  relatieveHoogteligging    0                       

A: begroeidterreindeel, grasland agrarisch

C: begroeidterreindeel, loofbos.

Objecttype: OndersteunendWaterdeel
----------------------------------

</div>
