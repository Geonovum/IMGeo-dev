<div>

### OndersteunendWegdeel, functie: berm, fysiek voorkomen onverhard

</div>
