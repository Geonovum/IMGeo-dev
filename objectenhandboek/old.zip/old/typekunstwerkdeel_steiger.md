<div>

### Kunstwerkdeel, type: steiger

![DSC01139](media/image87.jpg)

B:

  ------------------------ --------------------- -----------------
  **Kunstwerkdeel**        **Attribuutwaarde**   **Opmerkingen**
  type                     steiger               
  relatieveHoogteligging   1                     
  ------------------------ --------------------- -----------------

![jd19](media/image88.jpg)

Drijvende steigers zijn geen BGT inhoud.

</div>
