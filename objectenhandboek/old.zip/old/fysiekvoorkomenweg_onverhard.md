<div>

### Wegdeel, fysiekVoorkomen: onverhard

![](media/image27.jpg)

A:

  ------------------------ ---------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**    **Opmerkingen**
  functie                   Rijbaan: lokale weg    
  fysiekVoorkomen          onverhard               
  relatieveHoogteligging    0                      
  ------------------------ ---------------------- -----------------

Objecttype: OndersteunendWegdeel
--------------------------------

</div>
