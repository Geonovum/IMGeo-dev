<div>

### Waterdeel, type: waterloop

![](media/image57.jpg)

D:

  ------------------------ --------------------- -----------------
  **Waterdeel**            **Attribuutwaarde**   **Opmerkingen**
  type                     waterloop              
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

A: wegdeel, rijbaan: lokale weg, open verharding

B en E: ondersteunend waterdeel, oever/slootkant.

C: scheiding, kademuur.

![Wegdeel met berm en ondergronds waterdeel](media/image58.jpg)

Duikers vormen geen inhoud BGT.

F: Het niet zichtbare waterdeel in duiker is géén BGT-inhoud.

</div>
