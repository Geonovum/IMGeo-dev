<div>

### Wegdeel, functie: inrit

![](media/image8.jpg)

B:

  ------------------------ ---------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**    **Opmerkingen**
  functie                  inrit                   
  fysiekVoorkomen           Gesloten verharding    
  relatieveHoogteligging    0                      
  ------------------------ ---------------------- -----------------

A: Wegdeel, Rijbaan, Regionale weg, Gesloten verharding.

C: Ondersteunend wegdeel: Berm, fysiek voorkomen: Groenvoorziening.

</div>
