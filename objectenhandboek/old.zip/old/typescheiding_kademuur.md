<div>

### Scheiding, type: kademuur

![](media/image91.jpg)

C:

  ------------------------ --------------------- -----------------
  **Scheiding**            **Attribuutwaarde**   **Opmerkingen**
  type                     kademuur               
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

![kademuur2.jpg](media/image92.jpg)

Hek C wordt **niet** opgenomen in de BGT omdat het op scheiding kademuur
staat, deze gaat voor in de hiërarchie bij scheidingen.

A:

  ***Scheiding***          ***Attribuutwaarde***   ***Opmerkingen***
  ------------------------ ----------------------- -------------------
  typeScheiding            Kademuur                
  relatieveHoogteligging    0                      

B: overbruggingsdeel en wegdeel, beide op niveau 1.

</div>
