<div>

### Wegdeel, fysiekVoorkomen: half verhard

![](media/image26.jpg)

A:

  ------------------------ --------------------- -----------------
  **Wegdeel**              **Attribuutwaarde**   **Opmerkingen**
  functie                   voetpad               
  fysiekVoorkomen          half verhard           
  relatieveHoogteligging    0                     
  ------------------------ --------------------- -----------------

</div>
